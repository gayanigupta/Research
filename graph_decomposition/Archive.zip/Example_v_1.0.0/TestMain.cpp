//INPUT HEADERS


//#include<iostream>
//#include<stdio.h>
#include"structure_defs.hpp"
#include"network_defs.hpp"

//OUTPUT HEADERS




/*** All Headers Required From ESSENS **/

using namespace std;

int main()
{
    cout<<"Hello Fool"<<endl;
    A_Network a_network;
    a_network[0].Ops[0]=5;
      cout<<"Ops"<< a_network[0].Ops[0]<<endl;

   return 1;
}
